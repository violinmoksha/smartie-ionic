import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PaymentthankyouPage } from './paymentthankyou';

@NgModule({
  declarations: [
    PaymentthankyouPage,
  ],
  imports: [
    IonicPageModule.forChild(PaymentthankyouPage),
  ],
})
export class PaymentthankyouPageModule {}
