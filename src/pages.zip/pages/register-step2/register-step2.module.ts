import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RegisterStep2Page } from './register-step2';

@NgModule({
  declarations: [
    RegisterStep2Page,
  ],
  imports: [
    IonicPageModule.forChild(RegisterStep2Page),
  ],
})
export class RegisterStep2PageModule {}
